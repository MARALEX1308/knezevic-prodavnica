<?php
// Povezivanje sa bazom podataka
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "prodavnica";

$conn = new mysqli($servername, $username, $password, $dbname);

// Provera konekcije
if ($conn->connect_error) {
    die("Konekcija nije uspela: " . $conn->connect_error);
}

// Provera da li je forma poslata
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Preuzimanje podataka iz forme
    $ime_prezime = $_POST['ime_prezime'];
    $datum = $_POST['datum'];
    $proizvod = $_POST['proizvod'];
    $kolicina = $_POST['kolicina'];

    // SQL upit za unos podataka u tabelu porucbenica
    $sql = "INSERT INTO porucbenica (ime_prezime, datum, proizvod, kolicina) 
            VALUES ('$ime_prezime', '$datum', '$proizvod', '$kolicina')";

    // Izvršavanje SQL upita
    if ($conn->query($sql) === TRUE) {
        echo "Podaci su uspešno upisani.";
    } else {
        echo "Greška: " . $sql . "<br>" . $conn->error;
    }
}

// Zatvaranje konekcije
$conn->close();
?>

<!-- Forma za unos podataka -->
<!DOCTYPE html>
<html>
<head>
    <title>Poručbenica</title>
</head>
<body>
    <div class="container mt-5">
        <div class="mb3">
            <h2 class="mb3"><i class="bi bi-signal"></i>Porucbenica</h2><hr>
        </div>
        <div class="mb3">
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="mb3">
                    <label for="ime_prezime" class="form-label">Ime i Prezime</label>
                    <input type="text" required class="form-control" name="ime_prezime">
                </div>
                 <div class="mb3">
                    <label for="datum" class="form-label">Datum</label>
                    <input type="date" required class="form-control" name="datum">
                </div>
                 <div class="mb3">
                    <label for="proizvod" class="form-label">Proizvod</label>
                    <select required class="form-control" name="proizvod">
                        <option value="tvrdi_sir">Tvrdi Sir</option>
                        <option value="mladi_sir">Mladi Sir</option>
                        <option value="sveze_mleko">Sveze Mleko</option>
                        <option value="jaja">Jaja</option>
                    </select>
                </div>
                 <div class="mb3">
                    <label for="kolicina" class="form-label">Kolicina</label>
                    <input type="number" required class="form-control" name="kolicina">
                </div>
                <div>
                    <hr>
                    <button type="submit" class="btn btn-primary">Naruci</button>
                </div>
                
            </form>
        </div>
        




    </div>



</body>
</html>
